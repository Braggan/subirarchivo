<?php 

if (isset($_POST['subir']) and !empty($_FILES)) 
	{  /** Se indica el mismo metodo POST del formulario con el name del boton submit y con empty validamos que archivo no este vacio **/
	 $destino = 'subidos/';				//Destino donde se guardan los archivos
	 $nombre = $_FILES['archivos']['name'];
	 $tmp = $_FILES['archivos']['tmp_name'];
	 $nuevo = $_POST['nombre']; 		//Nuevo nombre del archivo
	 $tipo = explode('.', $nombre); 	//Esto me ayuda a guardar el nombre con su formato o tipo de archivo
	 $tipo = end($tipo); 				// Aqui tomamos la ultima posicion del Array la cual es el tipo para guardarla
	 
	 if ($tipo == 'jpg' || $tipo == 'JPG' || $tipo == 'png' || $tipo == 'PNG') //Validar el tipo de archivo antes de subirlo
	 {
	 	move_uploaded_file($tmp, $destino . $nuevo . '.' . $tipo);
	 	echo "Archivo subido correctamente";
	 }
	 else
	 {
	 	echo "Formato de archivo no soportado";
	 }
	}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Subir</title>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
	<input type="text" name="nombre" placeholder="Nombre del archivo"><br>
	<input type="file" name="archivos" id=""><br>
	<input type="submit" value="Subir" name="subir">
</form>
</body>
</html>